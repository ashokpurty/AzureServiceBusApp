﻿using Microsoft.Azure.ServiceBus;
using System;
using System.Text;

namespace AzureServiceBusApp
{
    public class ServiceBusSender
    {
        string QueueAccessKey = "Shared access policy key";
        public void SendMessage(string messgae)
        {
            ServiceBusConnectionStringBuilder conStr;
            QueueClient client;
            try
            {
                conStr = new ServiceBusConnectionStringBuilder(QueueAccessKey);
                client = new QueueClient(conStr);
                Message msg = new Message();
                msg.Body = Encoding.UTF8.GetBytes(messgae);
                Console.WriteLine("Please wait....message sending operation in progress.");
                client.SendAsync(msg).Wait();
            }
            catch (Exception exe)
            {
                Console.WriteLine("{0}", exe.Message);
                Console.WriteLine("Please restart application ");
            }
        }
    }
}
